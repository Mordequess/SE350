#ifndef STRESS_PROC_H
#define STRESS_PROC_H

void stress_proc_a(void);
void stress_proc_b(void);
void stress_proc_c(void);

#endif
