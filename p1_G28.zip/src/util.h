#ifndef UTIL_H
#define UTIL_H

void assert(int, unsigned char *);


#endif
