#ifndef USR_PROC_H
#define USR_PROC_H

void set_test_procs(void);
void proc1(void);
void proc2(void);
void proc3(void);
void proc4(void);
void proc5(void);
void proc6(void);

#endif
